<div class="login-popup">
    <div class="login-popup1"></div>
    <div class="login-popup2">
        <div class="login-hold">
            <form action="/login" method="post">
                <fieldset class="">
                    <input type="hidden" name="type" value="<?php echo $type; ?>">
                    <div class="fl">
                        <div class="row">
                            <label>User Name:</label>
                            <span class="set1-input">
                                <input class="" type="text" name="login" value="" />
                            </span>
                        </div>
                        <div class="row">
                            <label>Password:</label>
                            <span class="set1-input">
                                <input class="" type="password" name="password" value="" />
                            </span>
                        </div>
                    </div>
                    <div class="creat_account">
                        <a href="" class="">Create a free blogger account</a>
                        <a href="" class="tw-sign"></a>
                        <a href="" class="sign"></a>
                        <div class="bor-top">
                            <a href="" class="">Forget User Name?</a>
                            <a href="" class="">|</a>
                            <a href="" class="">Forget Password?</a>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
    <div class="login-popup3"></div>
</div>